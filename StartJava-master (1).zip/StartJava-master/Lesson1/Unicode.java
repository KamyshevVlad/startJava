public class Unicode {

    public static void main (String [] args) {

    	for (char symbolNumber = 33; symbolNumber <= 126; symbolNumber++) {
        	System.out.println(symbolNumber);
    	}
    }
}